<?php

namespace Diadal\Passport\Http\Controllers;

use \Laravel\Passport\Http\Controllers\TransientTokenController as TransientTokenControllerDiadal;

class TransientTokenController extends TransientTokenControllerDiadal
{
    
    
}
