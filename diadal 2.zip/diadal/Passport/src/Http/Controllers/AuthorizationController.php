<?php

namespace Diadal\Passport\Http\Controllers;

use Illuminate\Http\Request;
use Diadal\Passport\Passport;
use Diadal\Passport\TokenRepository;
use Diadal\Passport\ClientRepository;
use Laravel\Passport\Http\Controllers\AuthorizationController as AuthorizationControllerDiadal;

class AuthorizationController extends AuthorizationControllerDiadal
{
    
    
}
