<?php

namespace Diadal\Passport\Http\Controllers;

use \Laravel\Passport\Http\Controllers\RetrievesAuthRequestFromSession as RetrievesAuthRequestFromSessionDiadal;

trait RetrievesAuthRequestFromSession
{
    
    use RetrievesAuthRequestFromSessionDiadal;
}
