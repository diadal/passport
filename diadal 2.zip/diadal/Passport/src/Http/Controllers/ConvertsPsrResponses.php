<?php
namespace Diadal\Passport\Http\Controllers;

use \Laravel\Passport\Http\Controllers\ConvertsPsrResponses as ConvertsPsrResponsesDiadal;

trait ConvertsPsrResponses
{
    use ConvertsPsrResponsesDiadal;
}
