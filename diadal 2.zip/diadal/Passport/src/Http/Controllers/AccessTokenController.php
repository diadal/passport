<?php

namespace Diadal\Passport\Http\Controllers;

use Diadal\Passport\TokenRepository;
use Laravel\Passport\Http\Controllers\AccessTokenController as AccessTokenControllerDiadal;


class AccessTokenController extends AccessTokenControllerDiadal
{
   
}
