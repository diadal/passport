<?php

namespace Diadal\Passport\Http\Controllers;

use \Laravel\Passport\Http\Controllers\DenyAuthorizationController as DenyAuthorizationControllerDiadal;

class DenyAuthorizationController extends DenyAuthorizationControllerDiadal
{
    
}
