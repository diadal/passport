<?php

namespace Diadal\Passport\Http\Controllers;

use \Laravel\Passport\Http\Controllers\PersonalAccessTokenController as PersonalAccessTokenControllerDiadal;

class PersonalAccessTokenController extends PersonalAccessTokenControllerDiadal
{
    
}
