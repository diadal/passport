<?php

namespace Diadal\Passport\Http\Controllers;

use \Laravel\Passport\Http\Controllers\ScopeController as ScopeControllerDiadal;

class ScopeController extends ScopeControllerDiadal
{
    
}
