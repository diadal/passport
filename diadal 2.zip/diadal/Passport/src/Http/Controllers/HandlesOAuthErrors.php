<?php

namespace Diadal\Passport\Http\Controllers;

use \Laravel\Passport\Http\Controllers\HandlesOAuthErrors as HandlesOAuthErrorsDiadal;

trait HandlesOAuthErrors
{
    use HandlesOAuthErrorsDiadal;

}
