<?php

namespace Diadal\Passport\Http\Controllers;

use Laravel\Passport\Http\Controllers\AuthorizedAccessTokenController as AuthorizedAccessTokenControllerDiadal;

class AuthorizedAccessTokenController extends AuthorizedAccessTokenControllerDiadal
{
    
}
